HOW TO ACCESS THE WEBSITE:
1. Open the folder WebThink where you can find the files and resources for the website.
2. Right click and open the file "midterm". To choose what browser to use, 
right click then click "open with" and choose your prefered browser.
3. You can shift from prelim to midterm course notes 
by clicking what you choose from the navigation bar.
 